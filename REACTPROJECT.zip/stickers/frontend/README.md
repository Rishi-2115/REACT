https://dribbble.com/shots/21243238-Trading-App

https://cdn.dribbble.com/users/551602/screenshots/12780467/media/38fdc174630f7d302b5fdd71125ed67e.mp4

https://cdn.dribbble.com/userupload/11900236/file/original-a85b1ae55afb1bb882c42cdd5c2701b5.gif

Loading
https://codepen.io/BrianSipple/pen/vOmzoG

icons / btns
https://codepen.io/Stockin/pen/XPvpoB 

https://webdeasy.de/en/css-loader/

https://codepen.io/ThePooley/pen/MWbKBNV