export default function ErrorPage({msg}){
    return <h1 className="ErrH">{msg}</h1>
}