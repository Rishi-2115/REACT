export default function Landing(){
    
}