export default function DancingIcon() {
  return (
    // <div id="dancingIcon-area">
      <div id="dancingIcon-container">
          <img src="/imgs/ethereumBlack.png" alt="" />
        <div id="dancingIcon">
        </div>
      </div>
    // </div>
  );
}
