export default function ErrorPage({msg}){
    return (
        <h1>Error ho gaya : {msg}</h1>
    )
}